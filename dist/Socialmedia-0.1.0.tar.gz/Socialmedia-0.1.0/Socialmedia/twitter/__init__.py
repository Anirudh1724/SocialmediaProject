from . import extractor

class Twitter:
    def run(self):
        extractor.main()
from . import extractor

class Threads:
    def run(self):
        extractor.main()
from . import extractor

class Youtube:
    def run(self):
        extractor.main()
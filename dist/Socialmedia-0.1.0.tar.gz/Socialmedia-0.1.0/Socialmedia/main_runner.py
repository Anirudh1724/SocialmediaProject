from Socialmedia import quora

def main():
    ig = quora.Quora()
    ig.run()

if __name__ == "__main__":
    main()

from . import extractor

class Instagram:
    def run(self):
        extractor.main()
